Python 3.11.1 (tags/v3.11.1:a7a450f, Dec  6 2022, 19:58:39) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
===================== RESTART: C:/ADHI.PY/insertion sort.py ====================
Traceback (most recent call last):
  File "C:/ADHI.PY/insertion sort.py", line 10, in <module>
    my_list[9,4,7,2,5,3,1,8,6]
NameError: name 'my_list' is not defined
>>> 
===================== RESTART: C:/ADHI.PY/insertion sort.py ====================
Traceback (most recent call last):
  File "C:/ADHI.PY/insertion sort.py", line 11, in <module>
    sorted_list=insertion-sort(my_list)
NameError: name 'insertion' is not defined
>>> 
===================== RESTART: C:/ADHI.PY/insertion sort.py ====================
[1, 2, 3, 4, 5, 6, 7, 8, 9]
